---
name: tri-net
description: "TRI-NET — open secure radio-mesh on FPGA nodes. MVP node = P201Mini/P203Mini all-in-one SDR+FPGA board (Zynq-7020, AD9361/AD9363, GbE, GPS/PPS sync, 85x50mm, flyable); 3 owned. Includes DRONE-MESH aerial layer (drone relay swarm = Starlink-without-satellites: if one node has uplink, internet reaches the whole drone/robot swarm). Load for TRI-NET radio MVP, mesh networking, SDR/FPGA radio PHY, video-over-radio (видео-рации), drone/FANET aerial relay swarm, tethered-drone internet, or delivering internet to remote areas. Covers hardware (3x P201/P203 Mini MVP node, 3x AX7203 ground/dev, optional AntSDR E200), flyability, the gHashTag code stack (trios-mesh routing, X25519+ChaCha20, tt-trinity-gamma NoC, trinity-fpga), FANET science base, weak points (PA power/NBTC/IMDA/latency/security), phased roadmap (bench to fixed nodes to tethered drone to swarm), tech tree."
license: Apache-2.0
metadata:
  author: gHashTag / Vasilev Dmitrii
  version: '2.3'
  line: TRI-NET
  anchor: "phi^2 + phi^-2 = 3"
  contact: admin@t27.ai
  orcid: 0009-0008-4294-6159
---

# TRI-NET — Open Secure Radio Mesh on Native FPGA Nodes

> Anchor: φ² + φ⁻² = 3 · Trinity Project · TRI-NET line · gHashTag · Таиланд
> Snapshot verified against live GitHub state on 2026-06-30.
> v2.1: MVP железо уточнено — узел = плата P201Mini/P203Mini (3 в наличии), спеки из datasheet.
> v2.2: ЧЕСТНЫЙ СТАТУС железа — FPGA ЕЩЁ НЕ ПРОШИВАЛИ, тулчейн НЕ настроен, сетевой стек на узлах НЕ запускался (только код + юнит-тесты в симуляции). Сроки сжаты под vibe-coding. Видео-рация = и видеосвязь, и канал управления дронами (двойное назначение одного радиоканала).
> v2.3: ЧАСТИЧНО НА ЖЕЛЕЗЕ (2026-07-01) — M1 crypto-smoke (RC=0, sha256 e5abc335…), AD9361 5.8ГГц цифровой loopback (пик FFT +0.999МГц, 108.6дБ), M3 mesh 11→13 (ETX сошлась, 2 хопа). Полный PHY/TDMA/полёты — по-прежнему только в симуляции.

## When to Use This Skill

Load this skill when the task involves any of:

- TRI-NET radio MVP — building/testing the 3-node mesh radio prototype
- Mesh networking on Trinity nodes (routing, ETX metric, convergence, NoC)
- SDR / FPGA radio PHY (P201/P203 Mini integrated SDR+FPGA IQ pipeline, modulation, demod)
- Video-over-radio / видео-рации (low-latency FPGA video, push-to-talk) — тот же радиоканал служит и C2-каналом управления дронами (телеметрия + команды)
- Delivering internet to remote / hard-to-reach areas (backhaul + distribution)
- **DRONE-MESH / рой дронов-ретрансляторов** — воздушная FANET-сеть, аналог Starlink без спутников
- Partner proposal / budgeting / roadmap for the TRI-NET radio line

This skill is the single source of truth (SSOT) for what TRI-NET radio IS,
what hardware exists, what code is already written, and what remains to MVP.

---

## 1 · The One-Paragraph Summary

TRI-NET is an open, secure radio network built on native FPGA nodes. **MVP узел =
одна плата P201Mini / P203Mini** (PuZhi Tech / PZSDR) — all-in-one SDR+FPGA: на одной
плате стоят и радио (AD9361 для P201, AD9363 для P203), и ПЛИС (**Zynq-7020,
XC7Z020, 85K logic cells, dual Cortex-A9 @766 MHz, 1 GB DDR3**), и Gigabit
Ethernet, и **встроенная GPS/PPS+10MHz синхронизация** (0.1 ppm VCTCXO). Размер
платы **85×50 мм**, питание 5V/1A — узел компактный и **пригоден к полёту**. У нас
уже есть **3 такие платы** — это и есть железо первого MVP-кольца (треугольник
из 3 узлов). There is **no host PC** in the data path — the FPGA does receive,
decode, route. The mesh routing layer, end-to-end crypto, and parts of the
on-chip NoC **are written and pass unit-tests in simulation** in the gHashTag
code stack. **ЧАСТИЧНО НА ЖЕЛЕЗЕ (2026-07-01):** M1 crypto-smoke (RC=0, sha256 e5abc335…),
AD9361 5.8ГГц цифровой loopback (пик FFT +0.999МГц, 108.6дБ) и M3 mesh 11→13 (ETX
сошлась, пакет прошёл 2 хопа по Ethernet) — прогнаны на P201Mini. Тулчейн bring-up
ЧАСТИЧНО выполнен (крипто/mesh/loopback реально гоняли на железе Mini), но **полная
FPGA-прошивка PHY (bitstream flashing PL) НЕ сделана**. Генеральные пробелы:
(1) полный radio PHY в PL (SDR↔FPGA IQ pipeline), (2) **video transport (видео-рация
= видео + C2-управление дронами)**, (3) TDMA, (4) полёты.
3× AX7203 (в наличии) остаются для наземной разработки / фиксированных узлов /
тяжёлых вычислений при расширении; AntSDR E200 — опциональная альтернатива. Спеки
плат — в `references/p201mini_p203mini_datasheet_facts.md` (или research/). This skill maps it all.

**DRONE-MESH видение (аналог Starlink без спутников):** те же узлы поднимаются в воздух
на дронах и образуют летающую mesh-сеть (FANET). Если хотя бы один дрон имеет
аплинк (Starlink Mini / 4G/5G / волокно), интернет распространяется по всему рою
дронов и наземным роботам через mesh-маршрутизацию. Критичный инженерный
факт: P201/P203 Mini компактны (85×50 мм, 5V/1A, встроенный GPS/PPS) → **пригодны
к полёту**, в отличие от **AX7203** (>1 кг с радиатором, настольная, НЕ летает).
Путь к рою идёт через 4 фазы: стол → фиксированные высотные узлы → привязной
дрон → свободный полёт. Подробности — в `references/drone-mesh.md`.

## 2 · Hardware Inventory (what we physically have / need)

### Already owned — ОСНОВНОЕ MVP-железо
[CITED: P201Mini_P203Mini User Manual V1.0 2023.05.25, PuZhi Tech / PZSDR]
| Item | Qty | Spec | Status |
|------|----:|------|--------|
| **P201Mini / P203Mini board** (all-in-one SDR+FPGA) | **3** | **Zynq-7020 (XC7Z020), 85K LC, dual A9 @766 MHz, 1 GB DDR3**. P201=AD9361 70M–6 GHz BW 56M; P203=AD9363 325M–3.8 GHz BW 20M. 1× GbE, GPS/PPS+10M sync (0.1 ppm), 85×50 mm, 5V/1A. **Пригодна к полёту.** | In hand (3 шт) |
| ALINX AX7203 FPGA board | 3 | Xilinx Artix-7 **XC7A200T**, 740 DSP, 1 GB DDR3, **2× GbE** | In hand. **НЕ летает** → наземная разработка / фикс. узлы / расширение |

> **Стратегия:** MVP строится на 3× P201/P203 Mini (узел = одна плата, без отдельного SDR).
> P201Mini предпочтителен (70M–6G покрывает 5.8 ГГц ISM). Zynq-7020 → OpenXC7/Vivado +
> `openFPGALoader`. После MVP — расширение на AX7203 (тяжёлые вычисления, фикс. узлы).
> Полные спеки: `references/p201mini_p203mini_datasheet_facts.md`.

### To acquire (Tranche 2 — MVP enabler, уже не нужны SDR/PSU для AX7203)
| # | Item | Qty | Role |
|---|------|----:|------|
| 1 | Omni antenna 6 dBi 5 GHz SMA | 6 | 2 per node → MIMO 2×2, 100–500 m lab coverage |
| 2 | SMA–SMA cable 1 m | 6 | antenna ↔ плата (TX1/RX1 SMA) |
| 3 | **Внешний PA + LNA** (опц.) | 3 | PA на плате всего **10–15 dBm** → для дальности нужен внешний усилитель |
| 4 | Ethernet Cat6 3 m (node → user/next) | 3 | 1× GbE на плате |
| 5 | PSU 5V/2A (USB-C) | 3 | питание платы (TypeC) |
| 6 | SD card 16 GB | 3 | boot (JTAG/QSPI/SD) |
| 7 | USB-C cable | 3 | debug / power |
| 8 | **FT2232H** programmer | 1 | bitstream flashing (shared) — `openFPGALoader` |
| 9 | GPS-антенна / PPS кабель (mmcx) | 3 | внешняя синхро (опц.; вход есть на плате) |

> BOM резко дешевле исходного плана: отдельные AntSDR E200 больше не нужны (радио уже
> на плате). Основные затраты — антенны, опциональные PA/LNA и программатор.

### Single-node block diagram (P201/P203 Mini = весь узел на одной плате)
```
Antennas (5 GHz, 2× for MIMO) → TX1/RX1 SMA
        │
        ▼
┌────────── P201Mini / P203Mini ─────────┐
│  AD9361/AD9363 radio  (70M/325M – 6G/3.8G) │
│         ↓ (on-chip)                        │
│  Zynq-7020 FPGA HEART:                     │
│   · receive IQ     · demodulate / decode    │
│   · route (mesh)   · encrypt   · NO host PC │
│  GPS/PPS+10M sync (0.1 ppm) — для TDMA      │
└───────────── 1× GbE ─────────────────┘
        ▼
User / next node
```

Why no host PC: Zynq-7020 (85K LC, dual A9) делает PHY on-die → ниже потребление,
ниже latency, нет закрытой Intel/Microsoft attack surface. Toolchain открытый (`t27`,
`trinity-fpga`, `openFPGALoader`) — дорогая Vivado-лицензия не обязательна.
Встроенная GPS/PPS-синхронизация снимает главную проблему mesh — общий TDMA-слот
без отдельного GPSDO.

## 3 · Existing Code Stack (verified on GitHub gHashTag, 2026-06-30)

**Key correction discovered via code search:** the mesh layer is NOT greenfield.
A real, tested mesh stack already exists. Read `references/repo-inventory.md` for
the full map. Summary of what is DONE vs MISSING:

| Layer | Status | Where |
|-------|--------|-------|
| Mesh routing (ETX-like `cost = α·hops + β·quality`, α=1 β=2) | 🟢 базово прогнано на Mini (M3 11→13 на железе, 2026-07-01) + 🟡 полное покрытие в sim | `trios/crates/trios-mesh` (v0.2.0) |
| End-to-end crypto (X25519 ECDH + ChaCha20-Poly1305) | 🟢 базово прогнано на Mini (M1 crypto-smoke RC=0 на железе) + 🟡 полное покрытие в sim | `trios/crates/trios-mesh-node/src/crypto.rs` |
| Mesh daemon (axum: /announce /next-hop /encrypt /message) + Neon persistence | 🟡 код написан, локально; на узлах НЕ разворачивался | `trios/crates/trios-mesh-node` |
| Route stability (no-flap), Coq proofs `route_table_no_flap`, `MeshDeterminismCorrect.v` | ✅ proven | `trios/docs/phd` |
| Transport trait (LoRa SPI / UART / USB-serial slots) | ✅ trait exists, radio variant TODO | `trios-mesh/src/transport.rs` |
| Hardware Mesh Routing Unit (MRU) — `mru_forward` SRAM 16×32 B = 512 B | 🟡 spec'd, software mirror done | `trios-mesh` ↔ RTL |
| On-chip NoC RTL (2×2 GF16 mesh, N/S/E/W flit+req/ack) | 🟡 partial (stub + d2d_holo_mesh) | `tt-trinity-gamma/src/gf16_mesh_2x2_top.v` |
| Multi-tile NoC design doc | 🟡 doc | `trinity-fpga/docs/v3-squeeze/S-18-multi-tile-noc.md` |
| FPGA synth toolchain (OpenXC7/Vivado) — bring-up | 🟡 ЧАСТИЧНО: крипто/mesh/loopback реально гоняли на железе Mini (2026-07-01); полная FPGA-прошивка PHY НЕ сделана | `trinity-fpga` |
| Bitstream flashing (прошивка PL) | ❌ **полная FPGA-прошивка PHY (bitstream flashing PL) НЕ сделана** (радио проверено только через цифровой loopback) | `openFPGALoader` + FT2232H |
| DePIN daemon (attestation 2-of-3, JSON-RPC, P2P), Euler = "Routing/control · on-chip mesh NoC" | ✅ skeleton | `trinity-node` |
| On-chain billing (ERC-20 TRI, mining/claim) | ✅ contracts | `trinity-contracts` |
| Chips: Phi (id/trust), Euler (sig/routing), Gamma (compute), Corona (format oracle) | ✅ submitted, silicon 2026-10..12 | `tt-trinity-{phi,euler,gamma,corona}` |
| **Radio PHY: SDR IQ → FPGA demod/decode** | ❌ **MISSING — the real gap** | (new: `tri-net-radio`) |
| **Video transport over radio (видео-рации)** | ❌ **MISSING** | (new: `tri-net-radio`) |

> **ЧЕСТНЫЙ СТАТУС (2026-07-01, v2.3):** код выше уровня радио (routing, crypto, mesh-логика,
> NoC, billing, identity) **написан и проходит юнит-тесты в симуляции**. ЧАСТИЧНО НА
> ЖЕЛЕЗЕ: M1 crypto-smoke (RC=0), AD9361 loopback (пик FFT +0.999МГц, 108.6дБ) и M3 mesh
> 11→13 (пакет через 2 хопа) прогнаны на P201Mini. Тулчейн bring-up частично выполнен.
> **НЕ на железе:** полный PHY в PL, полная FPGA-прошивка bitstream, TDMA, видео-рация + C2,
> полёты. Преимущество: код-база зрелая → благодаря vibe-coding сроки сжаты (см. §4).

## 4 · MVP Roadmap

Read `references/roadmap-mvp.md` for the full phase-by-phase plan. **Timeline
сжат под vibe-coding** — мы не пишем руками, а генерируем код, и базовый mesh/crypto
уже написан (только в симуляции). **Реальный критический путь = железо**
(bring-up тулчейна → первая прошивка → radio PHY), потому что этого нельзя ускорить
генерацией кода — это паяльник, осциллограф и реальные радиоволны.

**Headline-фазы (сжатый vibe-coding timeline, узел = P201/P203 Mini, 3 в наличии):**
- **P0 · Toolchain bring-up + первая прошивка (нед. 1) — ЧАСТИЧНО ВЫПОЛНЕНА:** M1
  crypto-smoke (RC=0), AD9361 loopback и M3 mesh 11→13 прогнаны на P201Mini
  (2026-07-01). Остаётся: поднять OpenXC7/Vivado, собрать blink-битстрим,
  **полная FPGA-прошивка PHY (bitstream flashing PL)**, завести репо `tri-net-radio`.
- **P1 · Radio PHY baseline (нед. 2–3):** AD9361/AD9363 → Zynq PL IQ pipeline,
  TX/RX BPSK/QPSK, CRC, петля loopback на одной плате, затем линк между 2 платами.
- **P2 · trios-mesh на железе + DEMO GATE (нед. 4–5):** поднять существующий
  `trios-mesh` (реализовать radio-variant `transport.rs`) поверх PHY на 3 узлах.
  **⚡ DEMO GATE ≈ нед. 5–6:** 3 узла-треугольник передают данные по радио,
  самовосстановление при отказе узла, метрики + видеозапись.
- **P3 · Видео-рация = C2-канал (нед. 6–8):** низколатентное видео по тому же
  радио + **тот же канал несёт телеметрию/команды управления дронами (C2)** —
  push-to-talk голос/видео и управление роём по одному радиоканалу; AES/FHSS в FPGA.
- **P4 · Outdoor + привязной дрон (мес. 3–5):** вынос на улицу, внешние PA/LNA,
  фиксированные высотные узлы → привязной дрон (AT&T Flying COW как образец).
- **P5 · Свободный полёт + сервис (мес. 6+):** рой дронов-ретрансляторов +
  доставка интернета в удалённые районы (BVLOS-разрешения идут параллельно).

> **Почему недели, а не месяцы:** mesh-маршрутизация, крипто, NoC и демон
> уже написаны (в симуляции) → их надо «только» запустить на железе. **Несжимаемый
> риск — физика железа:** P0 (первая прошивка) и P1 (IQ-pipeline) могут
> растянуться из-за отладки SDR↔FPGA — закладывать +50–100% буфера на них.
> Оценки сроков — [оценка], не обещание.

## 5 · Tech Tree

Read `references/tech-tree.md` for the full dependency tree (foundations →
node hardware → radio PHY → mesh → video → service), each node tagged
DONE / PARTIAL / TODO. Use it to decide what can be worked on in parallel and
what is blocked on the radio PHY.

## 6 · DRONE-MESH — воздушный слой (аналог Starlink без спутников)

Полная карта воздушного слоя — в `references/drone-mesh.md` (FANET научная база, слабые места,
регуляторика, BOM воздушного узла). Главные выводы:

**Архитектурные решения (не нарушать):**
- **Летающий узел = P201/P203 Mini** (85×50 мм, 5V/1A, GPS/PPS на борту). **AX7203 НЕ летает**
  (>1 кг) → наземная разработка / фиксированные узлы. AntSDR E200 (~200г) — опциональная альтернатива.
- **Треугольник, не цепочка:** 3 узла должны быть в взаимной радиовидимости —
  только треугольник даёт самовосстановление (при отказе одного узла). Цепочка A–B–C
  при отказе B разрывает сеть. [CITED: Liu&Zhang 2024; Park 2020]
- **Привязной дрон (AT&T Flying COW) = главный образец** — тетер даёт питание +
  волокно, решает главную проблему FANET (эндюранс), работает 24/7. [CITED]
- **Частота: 5.8 ГГц ≤100 мВт** — licensed-by-rule и в Таиланде (NBTC), и в
  Сингапуре (IMDA); AD9361 на P201Mini покрывает нативно (70M–6G). [CITED]
- **Синхронизация уже на борту:** GPS/PPS+10M вход и 0.1 ppm VCTCXO → общий TDMA-слот
  без внешнего GPSDO; это упрощает координацию роя и Remote-ID. [CITED: P201/P203 manual]
- **Маршрутизация:** для 3 узлов Babel или AODV > OLSR > BATMAN-adv (полевые
  испытания Guillen-Perez 2021). Но у нас уже есть свой `trios-mesh` (ETX) —
  использовать его поверх радио-транспорта.
- **Видео-рация = C2-канал управления (двойное назначение):** тот же радиоканал,
  что несёт видео/голос (push-to-talk), служит и каналом управления дронами —
  телеметрия вниз + команды/управление роём вверх. Один PHY, один стек шифрования,
  одна частота. Это снимает необходимость в отдельной C2-линии и упрощает SWaP
  воздушного узла. Канал C2 приоритизируется над видео (QoS) при перегрузке.

**Реалистичная пропускная способность:** 20–40 Мбит/с на конечный узел (3-node
mesh, half-duplex). На P201Mini BW до 56 МГц (AD9361), на P203Mini — до 20 МГц
(AD9363). Бутылочное горлышко — 1× GbE на плате. [CITED: P201/P203 manual]

**Главные слабые места (подробно в drone-mesh.md):**
1. Энергетика/эндюранс свободного полёта (20–45 мин) → решает тетер.
2. **Мощность PA: всего 10–15 dBm** на плате → для дальности нужен внешний PA + LNA. [CITED]
3. Регуляторика BVLOS (Singapore CAAS min 3 мес; Thailand NBTC реформа 2026).
4. Одна точка аплинка → треугольник + резервный аплинк.
5. Безопасность: открытый mesh перехватываем → FHSS + AES-256 (уже есть ChaCha20).

## 7 · Working Rules / Conventions

- License everything **Apache-2.0**, anchor line `φ² + φ⁻² = 3`.
- Keep the **hardware ↔ software correspondence** intact: `trios-mesh`
  constants (`MAX_ROUTES=16`, `QUALITY_W=4`, `ALPHA_HOPS`, `BETA_QUALITY`) must
  match the RTL MRU and Coq proofs — changing one requires re-running
  `cargo test -p trios-mesh --features std` AND the Coq gate.
- Mesh is **Reticulum-compatible** (same X25519 + ChaCha20-Poly1305 primitives) —
  preserve wire compatibility when extending packet formats.
- New radio work goes in a new `tri-net-radio` repo (rtl/ fpga/ firmware/ docs/),
  patterned on `trinity-fpga`; do NOT re-implement mesh routing — reuse `trios-mesh`.
- TRI-NET line chip order: Phi → Euler → Gamma → Corona → (radio = new).
- Honesty register discipline: tag claims `[VERIFIED]` (has a test/CI artifact),
  `[CITED]` (external source), `[Open conjecture]`. Do not over-claim TOPS/perf.

## 8 · Key Facts to Never Get Wrong

- **MVP узел = P201Mini / P203Mini** (PuZhi/PZSDR), all-in-one SDR+FPGA: Zynq-7020
  (XC7Z020, 85K LC, dual A9 @766 MHz), 1 GB DDR3, 1× GbE, GPS/PPS+10M (0.1 ppm),
  85×50 мм, 5V/1A. **3 в наличии, пригодны к полёту.** [CITED: manual V1.0]
  - **P201Mini** = AD9361, **70 MHz–6 GHz**, BW 200K–56 MHz (предпочтителен, покрывает 5.8G).
  - **P203Mini** = AD9363, **325 MHz–3.8 GHz**, BW 200K–20 MHz (drop-in, совместим).
  - PA на плате всего **10–15 dBm** → для дальности нужен внешний усилитель.
- AX7203 = **Artix-7 XC7A200T**, 740 DSP, 1 GB DDR3, **2× GbE**. 3 owned. **НЕ летает**
  (>1 кг с радиатором) → наземная разработка / фиксированные узлы / расширение.
- AntSDR E200 = AD9361, 70 MHz–6 GHz, Zynq-7020, ~200г — опциональная альтернатива.
- **ЧЕСТНЫЙ СТАТУС (v2.3, 2026-07-01):** частично на железе — M1 crypto-smoke (RC=0,
  sha256 e5abc335…), AD9361 5.8ГГц цифровой loopback (пик FFT +0.999МГц, 108.6дБ),
  M3 mesh 11→13 (ETX сошлась, 2 хопа) прогнаны на P201Mini. Тулчейн bring-up частично
  выполнен. **НЕ на железе:** полная FPGA-прошивка PHY (bitstream flashing PL),
  TDMA, видео + C2, полёты. Радио проверено только через цифровой loopback,
  не полный PHY в PL. НЕ заявлять «полная FPGA-прошивка работает».
- **Видео-рация = ДВОЙНОЕ назначение:** и видеосвязь (видео-рация), и **C2-канал
  управления дронами** (телеметрия + команды) по тому же радиоканалу. Один PHY.
- **DRONE-MESH:** треугольник (не цепочка); привязной дрон = образец (AT&T Flying COW);
  5.8 ГГц ≤100 мВт; реалистично 20–40 Мбит/с на узел; НЕ летать с первого дня.
- Demo gate ≈ **нед. 5–6** (сжато под vibe-coding): 3 узла передают данные по радио,
  самовосстановление, метрики + видеозапись. [оценка — несжимаемый риск в железе P0/P1.]
- Equity split in current proposal: investor 51% / founder 49%.
