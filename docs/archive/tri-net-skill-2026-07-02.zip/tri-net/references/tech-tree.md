# TRI-NET — TECH TREE

> v2.3 (2026-07-01): частично на железе — M1 crypto-smoke + AD9361 loopback + M3 mesh 11→13 прогнаны на P201Mini; полный PHY/TDMA/полёты по-прежнему только в симуляции.
> Dependency tree of technologies for the TRI-NET radio MVP and beyond.
> Each node tagged: ✅ DONE · 🟢 ON HW (hardware confirmed) · 🟡 PARTIAL · ❌ TODO · ⬜ FUTURE.
> An item is "unlockable" only when all its parents are ✅/🟢/🟡.
> Use this to decide what can be built in parallel vs what is blocked.

```
TRI-NET RADIO MESH (φ² + φ⁻² = 3)
│
├── TIER 0 · FOUNDATIONS ────────────────────────────────────────────────
│   ├── [✅] t27 SSOT toolchain (.t27 → Verilog → Tiny Tapeout)   gHashTag/t27
│   ├── [✅] GoldenFloat GF16 numeric core                        zig-golden-float
│   ├── [🟡] FPGA synth flow (OpenXC7/Vivado) — частично: крипто/mesh/loopback на Mini (2026-07-01);  trinity-fpga
│        полная FPGA-прошивка PHY (bitstream flashing PL) НЕ сделана
│   ├── [❌] Bitstream flashing PL (PHY) — НЕ сделано; радио проверено только через цифровой loopback  openFPGALoader+FT2232H
│   └── [✅] DePIN daemon skeleton (attest, JSON-RPC, P2P)        trinity-node
│
├── TIER 1 · NODE HARDWARE ───────────────────────────────────────────────
│   ├── [✅] 3× P201/P203 Mini (Zynq-7020, AD9361/63, GbE, GPS/PPS) OWNED ★MVP узел★
│   │        all-in-one SDR+FPGA; 85×50мм; ПРИГОДНЫ К ПОЛЁТУ
│   ├── [✅] 3× AX7203 (XC7A200T, 740 DSP, 1GB DDR3, 2×GbE)  OWNED (наземн./расшир.)
│   ├── [⬜] 3× AntSDR E200 (AD9361, 70MHz–6GHz, GbE)        опц. альтернатива
│   ├── [❌] Antennas / SMA cables / ext. PA+LNA / PSU 5V / SD / FT2232H  BUY
│   └── [❌] Power-on + GbE bring-up per P201/P203 Mini node  P0
│         └── unlocks ▶ everything radio
│
├── TIER 2 · RADIO PHY  ★ CRITICAL PATH ★ ───────────────────────────────
│   │   (parents: Node HW, FPGA flow, flashing)
│   ├── [❌] P201/P203 Mini SDR firmware/HDL (AD9361 driver, IIO)  P1
│   ├── [❌] Baseline TX/RX 5.8 GHz (BPSK/QPSK), SNR/range         P1
│   ├── [❌] On-chip IQ: AD9361 → Zynq-7020 PL (без внешнего GbE)   P1
│   ├── [❌] FPGA demod on Zynq-7020 (DSP), frame sync, CRC        P2  ← the hard part
│   ├── [❌] GPS/PPS-привязка слотов (TDMA), 0.1ppm clock          P2
│   └── [❌] 2-node → 3-node over-the-air link, metrics            P2
│         └── ▶▶ DEMO GATE (нед. 5–6, сжато под vibe-coding) ◀◀
│
├── TIER 3 · MESH  (КОД написан; M3 mesh 11→13 НА ЖЕЛЕЗЕ 2026-07-01; полное покрытие в sim) ──
│   │   (parent: Radio PHY link up)   🟢 = базово на железе, 🟡 = полное покрытие sim
│   ├── [🟢] Routing core ETX  cost=α·hops+β·quality (α1 β2)  trios-mesh v0.2.0 (M3 на железе)
│   ├── [🟡] Routing table 16-entry heapless (= MRU SRAM)     trios-mesh/routing.rs (sim)
│   ├── [🟡] Packet ANNOUNCE/DATA encode-decode               trios-mesh/packet.rs (sim)
│   ├── [🟡] Identity Ed25519/X25519 → DestHash               trios-mesh/identity.rs (sim)
│   ├── [🟡] No-flap stability + Coq proofs                   route_table_no_flap (proof)
│   ├── [✅] Transport trait (LoRa/UART/USB slots)            trios-mesh/transport.rs
│   ├── [❌] Radio Transport impl (NEW — plug Zynq-7020 PHY into mesh)  P2/P3b  ← only new mesh work
│   └── [🟡] Mesh daemon /announce /next-hop (axum)           trios-mesh-node (локально, НЕ на узлах)
│
├── TIER 3b · MESH CRYPTO  (М1 crypto-smoke НА ЖЕЛЕЗЕ 2026-07-01; полное покрытие в sim) ────────
│   ├── [🟢] X25519 ECDH + ChaCha20-Poly1305 E2E             trios-mesh-node/crypto.rs (M1 на железе)
│   ├── [🟡] Commutative KDF, dest_hash = SHA256(pk)[..16]   (sim)
│   └── [🟡] Neon Postgres route persistence (optional)       migrations/001
│
├── TIER 4 · ON-CHIP MESH (RTL → silicon) ────────────────────────────────
│   │   (parent: Mesh core; converges with chip line)
│   ├── [🟡] NoC 2×2 GF16 mesh (N/S/E/W flit+req/ack)        tt-trinity-gamma/gf16_mesh_2x2_top.v
│   ├── [🟡] die-to-die holo mesh                            tt-trinity-gamma/d2d_holo_mesh.v
│   ├── [🟡] Hardware MRU `mru_forward` SRAM 16×32B=512B     spec'd, SW mirror done
│   ├── [🟡] Multi-tile NoC design                           trinity-fpga/S-18-multi-tile-noc.md
│   └── [⬜] Lift routing fully into RTL MRU                  Q4 2026+
│
├── TIER 5 · VIDEO-РАЦИЯ = C2-КАНАЛ (двойное назначение) ──────────────────
│   │   (parent: stable radio PHY + mesh)  тот же радиоканал = видео + управление дронами
│   ├── [❌] FPGA H.264/MJPEG encode (low-latency ~5 µs)      P3
│   ├── [❌] Packetize video → AD9361 TX (тот же PHY)          P3
│   ├── [❌] C2-канал: телеметрия дронов вниз + команды вверх (QoS > видео)  P3
│   ├── [❌] Half-duplex push-to-talk + traffic priority      P3
│   └── [❌] AES-256 / FHSS in FPGA, bound to Phi(id)+Euler(sig)  P3
│
├── TIER 6 · CHIP LINE (silicon, parallel track) ─────────────────────────
│   ├── [✅] Phi  — id/trust, Lucas POST, seed 0x47C0         tt-trinity-phi   (Dec 2026)
│   ├── [✅] Euler — sig/ZK, routing/control                  tt-trinity-euler (Dec 2026)
│   ├── [✅] Gamma — 8×4 32-PE compute mesh                   tt-trinity-gamma (Dec 2026)
│   ├── [✅] Corona — format oracle ROM                       tt-trinity-corona(Oct–Nov 2026)
│   └── [❌] Radio chip-block (future, after FPGA proof)      ⬜
│
├── TIER 7 · REMOTE-INTERNET SERVICE ────────────────────────────────────
│   │   (parent: outdoor radio + mesh + billing)
│   ├── [⬜] Backhaul: Starlink LEO / Community Gateway / µwave PtP
│   ├── [⬜] Backbone: 5 GHz PtP (LoS) / TVWS UHF (NLoS) / Wi-Fi HaLow
│   ├── [⬜] Distribution: tri-band (backhaul vs client split, 2 GbE ports)
│   ├── [⬜] Spectrum/regulatory (Thailand: class-licensed 2.4/5 GHz; TVWS DB)
│   ├── [✅] On-chain billing (ERC-20 TRI, claim, registry)   trinity-contracts
│   └── [⬜] Incentivized mesh (Althea-style) via trinity-node DePIN
│
└── TIER 8 · DRONE-MESH (воздушный слой, аналог Starlink без спутников) ───
    │   (parent: outdoor radio PHY + mesh + service backhaul)
    │   ★ Полный разбор фаз/железа/слабых мест → references/drone-mesh.md ★
    ├── [✅] Полётный узел: P201/P203 Mini (85×50мм, 5V/1A) — пригоден к полёту
    │        (AX7203 НЕ летает; AntSDR E200 ~200г — опц. альтернатива)
    ├── [❌] Привязной дрон (tethered, модель AT&T Flying COW): питание+оптика по тросу
    ├── [❌] Треугольная топология (НЕ цепь): self-healing при 3 узлах в радиовидимости
    ├── [✅] Синхронизация на борту: GPS/PPS+10M вход, 0.1ppm VCTCXO (TDMA + Remote ID)
    │        (внешняя GPS-антенна через mmcx — опц. для лучшей точности)
    ├── [❌] Регуляторика BVLOS (Сингапур CAAS ≥3 мес / Таиланд NBTC+CAAT)
    └── [⬜] Свободный рой (free-flight swarm), Phase 3 — после привязного прототипа
```

## Reading the tree
- **Critical path = TIER 2 (Radio PHY).** Almost nothing downstream unlocks until
  the Zynq-7020 (на P201/P203 Mini) demodulates a real signal. Put the strongest effort here.
- **MVP = 3× P201/P203 Mini** (узел = одна плата: радио + ПЛИС + GbE + GPS/PPS).
  AX7203 (3 шт) и E200 — для расширения после MVP, не блокируют первое кольцо.
- **TIER 3 (Mesh) — код ~90% написан, НО ТОЛЬКО в симуляции** (юнит-тесты/Coq;
  на реальных узлах НИ РАЗУ не запускался). Новая mesh-работа = один `Transport` impl
  + ЗАПУСК всего стека на железе — do NOT rewrite routing/crypto.
- **Parallelizable now (not blocked on radio):**
  - TIER 4 RTL NoC/MRU refinement (HW, simulation-only).
  - TIER 3 radio-`Transport` scaffolding + tests on Loopback.
  - TIER 6 chip line (independent silicon track, already submitted).
- **Blocked until DEMO GATE (M2, нед. 5–6):** TIER 5 видео/C2, TIER 7 service.
- **ЧЕСТНЫЙ СТАТУС (v2.3, 2026-07-01):** частично на железе — M1 crypto-smoke,
  AD9361 loopback, M3 mesh 11→13 прогнаны на P201Mini. Тулчейн bring-up частично
  выполнен. НЕ на железе: полная FPGA-прошивка PHY PL, TDMA, видео, полёты.
  Сроки сжаты под vibe-coding (код-база зрелая), radio PHY PL — несжимаемый
  риск (физика, не код). [оценка]

## "Done vs Remaining" at a glance
| Area | Done | Remaining |
|------|------|-----------|
| Toolchain / flashing | 🟡 частично: крипто/mesh/loopback на железе Mini (2026-07-01) | полная FPGA-прошивка PHY (bitstream PL) |
| MVP node HW (P201/P203 Mini = SDR+FPGA+GbE+GPS) | ✅ owned ×3 | power-on + bring-up |
| Expansion compute HW (AX7203) | ✅ owned ×3 | для фикс. узлов/расширения |
| Antennas / ext. PA+LNA / cables | — | ❌ buy (PA на плате 10–15 dBm) |
| **Radio PHY (demod/CRC on Zynq-7020)** | — | ❌ **the main MVP build** |
| Mesh routing + crypto + daemon | 🟢 M1 crypto-smoke + M3 mesh 11→13 на железе (2026-07-01); 🟡 полное покрытие в sim | ❌ radio Transport + full железо (полный PHY) |
| On-chip NoC / MRU RTL | 🟡 partial | finish + lift routing to RTL |
| Видео-рация = C2 (видео + управление дронами, один PHY) | — | ❌ all (P3) |
| Chip line (Phi/Euler/Gamma/Corona) | ✅ submitted | silicon arrives Oct–Dec 2026 |
| Remote-internet service | 🟡 billing only | ❌ backhaul/backbone/regulatory (P5) |
```
