# TRI-NET — MVP Roadmap

> v2.3 (2026-07-01): частично на железе — M1 crypto-smoke + AD9361 loopback + M3 mesh 11→13 прогнаны на P201Mini; полный PHY/TDMA/полёты по-прежнему только в симуляции.
> Goal of MVP: 3 working TRI-NET nodes in a lab exchange data (and basic video)
> over radio between each other — no host PC, no internet — with recorded metrics.
> MVP NODE = 3× **P201Mini / P203Mini** (all-in-one SDR+FPGA boards, OWNED ✅).
> Each Mini = Zynq-7020 (Dual A9 + 85K LC) + AD9361/AD9363 + 1× GbE + GPS/PPS sync
> on ONE 85×50mm board, 5V/1A — so NO separate AntSDR E200 and NO separate AX7203
> are required for the MVP. 3× AX7203 (OWNED) = ground dev / heavy-compute / expansion.
> ЧЕСТНЫЙ СТАТУС (v2.3, 2026-07-01): ЧАСТИЧНО НА ЖЕЛЕЗЕ — M1 crypto-smoke (RC=0,
> sha256 e5abc335…), AD9361 5.8ГГц цифровой loopback (пик FFT +0.999МГц, 108.6дБ),
> M3 mesh 11→13 (ETX сошлась, 2 хопа по Ethernet) прогнаны на P201Mini.
> Тулчейн bring-up ЧАСТИЧНО выполнен. НЕ на железе: полный PHY в PL,
> полная FPGA-прошивка bitstream, TDMA, видео + C2, полёты.
> MVP-работа = (1) полный radio PHY в PL (on-chip Zynq-7020), (2) видео + C2, (3) TDMA.
> TIMELINE СЖАТ ПОД VIBE-CODING (не пишем руками): недели, не месяцы — но несжимаемый
> риск = физика железа (P0/P1, отладка SDR↔FPGA).
> ВИДЕО-РАЦИЯ = ДВОЙНОЕ НАЗНАЧЕНИЕ: тот же радиоканал = видеосвязь + C2-канал
> управления дронами (телеметрия + команды).
> CAVEAT: Mini on-board PA = only 10–15 dBm → external PA+LNA is critical for any range.

## Status legend
✅ DONE · 🟡 PARTIAL · ❌ TODO

---

## Phase 0 — Toolchain bring-up + ПЕРВАЯ прошивка (Week 1) — ЧАСТИЧНО ВЫПОЛНЕНА
**M1 crypto-smoke, AD9361 loopback и M3 mesh 11→13 через 2 хопа прогнаны на P201Mini (2026-07-01).
Остаётся: полная FPGA-прошивка PHY (bitstream flashing PL) + репо `tri-net-radio`.**
**Exit:** toolchain впервые поднят, первый битстрим реально прошит на Zynq-7020, repos scaffolded.
- [ ] Inventory the 3× P201Mini/P203Mini boards; confirm contents per Drive manual
      (AD9361/AD9363, Zynq-7020, DDR3 1GB, RTL8211 GbE, GPS, PPS+10M clock). (❌)
- [ ] Acquire external PA + LNA + antennas for 5 GHz (Mini PA only 10–15 dBm). (❌)
- [ ] Power-on all 3 Mini (5V/1A TypeC) + bench check the GbE port + GPS lock. (❌)
- [ ] Bring up Vivado/PetaLinux (Zynq-7020) per Drive `02.Software Tools` /
      `03.Boot Test`; flash a blink/test bitstream end-to-end. (❌)
- [ ] (dev/expansion) Power-on 3× AX7203; build `openFPGALoader`, confirm FT2232H
      sees XC7A200T — used as ground dev rigs / heavy-compute nodes, not flight. (❌)
- [✅] **Тулчейн частично поднят:** крипто/mesh/loopback реально гоняли на железе Mini
      (2026-07-01). Остаётся: полная FPGA-прошивка PHY PL (по-прежнему НЕ сделана). (🟡)
- [ ] Create repo **`tri-net-radio`** (Apache-2.0): `rtl/ fpga/ firmware/ docs/`,
      patterned on `trinity-fpga`. (❌)
- [ ] Open EPIC issue linking to `trinity-fpga#22` (Node E2E quality) lineage. (❌)

## Phase 1 — P201/P203 Mini baseline radio (Weeks 2–3)
**Exit:** two Minis exchange a known waveform; IQ flows on-chip (AD9361 → Zynq-7020).
- [ ] Bring up AD9361/AD9363 on each Mini (libiio/no-OS); confirm RF path with PA+LNA. (❌)
- [ ] Lab TX/RX test at 5 GHz (within 70M–6GHz P201 / 325M–3.8GHz P203 range),
      simple modulation (BPSK/QPSK); record SNR, range (target 100–500 m lab w/ ext PA). (❌)
- [ ] Wire on-chip IQ datapath: AD9361 LVDS → Zynq-7020 PL (NO Ethernet hop needed —
      SDR and FPGA are on the same board); baseline throughput/latency. (❌)
- [ ] Document waveform + framing assumptions in `tri-net-radio/docs`. (❌)

## Phase 2 — FPGA radio PHY + trios-mesh на железе (Weeks 4–5) — KEY MVP WORK
**Exit (DEMO GATE, Week 5–6):** 3 nodes pass data over radio to each other;
metrics (throughput, latency) recorded on video. This is the partner deliverable.
[оценка: несжимаемый риск — отладка SDR↔FPGA может сдвинуть гейт на 1–2 нед.]
- [ ] RTL: ingest on-chip IQ (AD9361 → PL) → demodulate (Zynq-7020 PL, 85K LC,
      220 DSP). Fits a compact PHY; offload heavy compute to AX7203 if needed. (❌)
- [ ] RTL: frame sync + CRC; expose clean byte stream to the Zynq ARM (soft layer). (❌)
- [ ] Loopback then over-the-air 2-node link bring-up. (❌)
- [ ] Scale to 3 nodes; capture pktloss / throughput / latency. (❌)
- [ ] **DEMO**: record video + metrics; publish to GitHub (Apache-2.0). (❌)
- [ ] Optional: produce Zenodo DOI for the radio-PHY component (as done for chips). (❌)

## Phase 3 — Видео-рация = C2-канал управления (Weeks 6–8) — ДВОЙНОЕ НАЗНАЧЕНИЕ
**Exit:** низколатентное видео/голос по радио И тот же канал несёт телеметрию/команды дронов.
- [ ] FPGA video: H.264/MJPEG encode → packetize → AD9361 TX (low latency ~5 µs в PL). (❌)
- [ ] **C2-канал управления дронами по тому же радио:** телеметрия вниз +
      команды/управление роём вверх; C2 приоритизируется над видео (QoS). (❌)
- [ ] Half-duplex push-to-talk по mesh, traffic prioritization. (❌)
- [ ] AES-256 / FHSS в FPGA для радио-линка; bind to chips Phi (id) + Euler (sig). (❌)

## Phase 3b — Mesh integration (параллельно P2–P3) — mostly REUSE
**Exit:** packets route across 3 nodes via the EXISTING mesh stack over radio.
- [ ] Implement a **radio `Transport`** for `trios-mesh` (`transport.rs` trait). (🟡 trait ✅, radio impl ❌)
- [ ] Run `trios-mesh-node` daemon on each Mini's Zynq-7020 ARM (Dual Cortex-A9
      @766MHz, runs Linux); migrate hot path into PL / AX7203 MRU later. (🟡)
- [ ] Validate ETX routing (`α·hops+β·quality`) + X25519/ChaCha20 crypto on the
      radio links — code already tested, just over the new transport. (✅ code / ❌ on-radio)
- [ ] Mind multi-hop degradation: throughput drops ~50–60% past 2–3 hops →
      topology with min hops + dedicated backhaul radio. ([CITED] mesh testbeds)
- [ ] Begin lifting routing into RTL MRU (`mru_forward`, link to `tt-trinity-gamma`
      NoC `gf16_mesh_2x2_top.v`). (🟡 partial RTL exists)

## Phase 4 — Outdoor + привязной дрон (месяцы 3–5)
**Exit:** вынос на улицу, внешние PA/LNA, фиксированные высотные узлы → привязной дрон.

## Phase 5 — Outdoor + remote-internet service (месяцы 6+)
**Exit:** field deployment delivering internet to a hard-to-reach area.
- [ ] Outdoor antennas, masts, autonomous power; field range tests. (❌)
- [ ] Backhaul: Starlink (LEO; fast, infra-free) or Community Gateway 1–10 Gbps;
      microwave 5 GHz PtP where line-of-sight exists. ([CITED])
- [ ] Inter-node backbone: 5 GHz PtP on LoS; TV White Space (UHF, 200+ MHz free
      rural spectrum) on NLoS / obstructions; watch Wi-Fi HaLow (802.11ah ~900 MHz).
      ([CITED])
- [ ] Distribution: tri-band (one 5 GHz dedicated backhaul, 2.4+5 GHz to clients).
      Note: P201/P203 Mini has only **1× GbE** → for split backhaul+distribution use
      an AX7203 (2× GbE) or an external switch at fixed/ground sites. ([CITED])
- [ ] Pilot: backhaul + 1 node + 3–5 households / community hall. ([CITED])
- [ ] Check national spectrum rules (Thailand / target region): 2.4/5 GHz usually
      class-licensed with power limits; TVWS needs a whitespace database. (❌)
- [ ] Billing/DePIN: meter traffic on-chain via `trinity-contracts` (ERC-20 TRI) +
      `trinity-node` daemon — Althea-style incentivized mesh. ([CITED])

## Phase 6 — DRONE-MESH воздушный слой (2027+) — аналог Starlink без спутников
**Цель:** рой дронов-ретрансляторов раздаёт интернет: если у одного узла есть
аплинк (Starlink Mini / наземный backhaul), сеть доступна всему рою дронов и роботов.
> Полный разбор (4 фазы: bench → фиксированные приподнятые узлы → привязной
> дрон → свободный рой), железо, энергетика и слабые места: **references/drone-mesh.md**.
- [ ] Phase 0 bench (нед. 1–8): радио-PHY на земле, без полётов. (см. Phase 0–2 выше)
- [ ] Phase 1 фиксированные приподнятые узлы (мачты/крыши) = СЕРВИСНЫЙ MVP, ключевой de-risk. (❌)
- [ ] Phase 2 привязной дрон (tethered, модель AT&T Flying COW): питание+оптика по тросу, 24/7. (❌)
- [ ] Phase 3 свободный рой (free-flight), требует BVLOS-разрешения. (❌)
- [ ] Полётный узел: P201/P203 Mini (85×50мм, 5V/1A — лёгкий, летает) = основной;
      AntSDR E200 (~200 г) = опц. альтернатива; AX7203 с радиатором >1 кг — НЕ летает. (CITED)
- [ ] Треугольная топология (не цепь): self-healing при 3 узлах в радиовидимости. (CITED)

---

## Milestone summary
| Milestone | When | Definition of done |
|-----------|------|--------------------|
| M0 Toolchain + ПЕРВАЯ прошивка | wk 1 | ЧАСТИЧНО ВЫПОЛНЕНО (2026-07-01): crypto-smoke RC=0, AD9361 loopback, mesh 11→13. Остаётся: полная FPGA-прошивка PHY PL. |
| M1 crypto-smoke / AD9361 loopback / M3 mesh | wk 1 | ✅ ВЫПОЛНЕНО на железе (P201Mini, 2026-07-01) |
| **M2 DEMO GATE** | **wk 5–6** | **3 nodes pass data over radio, metrics on video** [оценка] |
| M3 Видео + C2 | wk 6–8 | PTT видео/голос + C2-управление дронами по тому же радио, AES/FHSS в FPGA |
| M4 Field service | мес. 3–5 | outdoor + привязной дрон, internet в удалённый пилот |
| M5 Drone-mesh рой | мес. 6+ | привязной дрон-ретранслятор раздаёт аплинк рою (см. drone-mesh.md) |

## Critical path
Критический путь = **физика железа**, не код. Код (mesh/crypto/NoC) уже написан в
симуляции, и vibe-coding сжимает программную часть до дней. (v2.3) P0 частично
выполнена: M1 crypto-smoke, AD9361 loopback, M3 mesh 11→13 на железе. Остается:
(P0) полная FPGA-прошивка PHY PL; (P1–P2) radio PHY на Zynq-7020 PL (отладка SDR↔FPGA)
— эти фазы НЕЛЬЗЯ ускорить генерацией кода (паяльник, осциллограф, радиоволны)
→ закладывать +50–100% буфера. Mesh (P3b) — reuse, прототипируется параллельно на
АРМ. Видео+C2 (P3) и сервис (P4/P5) блокируются стабильным линком из P2. Второй
риск — RF link budget: Mini PA = 10–15 dBm, внешний PA+LNA надо закупить в P0,
иначе дальность будет непригодно короткой. Сроки — [оценка], не обещание.
