# TRI-NET — Repository Inventory & Code Map

> v2.3 (2026-07-01): частично на железе — M1 crypto-smoke + AD9361 loopback + M3 mesh 11→13 прогнаны на P201Mini; полный PHY/TDMA/полёты по-прежнему только в симуляции.
> Verified against live GitHub (org: gHashTag) on 2026-06-30.
> Read this when you need to know exactly where a capability lives and its status.

## A · The mesh stack already exists (key finding)

A code search (`org:gHashTag mesh`, 453 hits) revealed a real, tested mesh
implementation that is easy to miss if you only look at repo names. It lives
inside the **`trios`** monorepo.

### `gHashTag/trios` → `crates/trios-mesh` (v0.2.0, 2026-05-09)
`no_std`, Reticulum-compatible mesh routing core. Files:
- `src/lib.rs` — crate root, constants: `MAX_ROUTES = 16`, `DestHash = [u8;16]`
  (128-bit), `Quality = u8` (GF16 [0..15], lower = better).
- `src/identity.rs` — Ed25519/X25519 pubkey → φ-DestHash (`SHA256(pubkey)[..16]`).
- `src/routing.rs` — 16-entry heapless routing table (= MRU SRAM mirror):
  `process_announce` / `next_hop` / `expire`.
- `src/packet.rs` — ANNOUNCE / DATA header encode/decode.
- `src/transport.rs` — `Transport` trait + software Loopback. **Radio variant
  is the integration point for new SDR transport.** Existing slots in docs:
  LoRa SPI / UART / USB-serial.
- `ARCHITECTURE.md`, `README.md`, `BENCHMARK.md`, `benches/`.

**Routing metric (DONE, VERIFIED + 🟢 НА ЖЕЛЕЗЕ: M3 mesh 11→13 прогнано на P201Mini 2026-07-01):** ETX-like, no FPU needed:
`cost(route) = ALPHA_HOPS·hops + BETA_QUALITY·quality`, with `α=1, β=2`,
`quality` inverted (0 best … 15 worst) — matches Babel (RFC 8966 §3.5)
monotonicity. Fixes prior `FIND-001 [CRITICAL]` (old lexicographic
`(hops, quality)` chose a 2-hop/worst-quality path over 3-hop/best-link).
Route swaps only on **strict** `new_cost < old_cost` → no oscillation.
Tests: `cargo test -p trios-mesh --features std` → 9/9 green.

**Crypto (DONE, VERIFIED + 🟢 НА ЖЕЛЕЗЕ: M1 crypto-smoke RC=0 на P201Mini 2026-07-01):** in `trios-mesh-node/src/crypto.rs`.
X25519 ECDH between static `MeshKeypair`s; commutative KDF
`SHA256(dh_shared || min(pk) || max(pk))`; AEAD = ChaCha20-Poly1305 (12-byte
nonce prefixed, base64 out). Same primitives as Reticulum → wire-level interop
is a format decision only.

**Stability / proofs (DONE):** Coq lemma `route_table_no_flap` (L-R14,
trios#586); theorem `docs/phd/theorems/igla/MeshDeterminismCorrect.v`;
academic write-up `docs/phd/chapters/ch_35_mesh_node.tex`.

### `gHashTag/trios` → `crates/trios-mesh-node`
axum daemon. Endpoints: `/health /info /announce /next-hop /encrypt /message`.
- `migrations/001_route_table.sql` — Neon Postgres route mirror (🟡 optional,
  enabled only when `DATABASE_URL` set; cuts post-restart convergence 30–120 s → <5 s).
- `railway.node0.toml`, `Dockerfile` — Railway deploy.
- `src/bin/e2e_25.rs` — end-to-end test harness.

**Benchmark posture (BENCHMARK.md):** vs Reticulum / MeshCore / Babel. Trinity
adds **0 B/s background broadcast** (pull model) `[VERIFIED]` vs Babel ~750 B/s
`[CITED]`. Direct cross-stack perf numbers tagged `[CITED]`, not re-measured.

## B · Hardware mesh / NoC (RTL)

### `gHashTag/tt-trinity-gamma` (Verilog)
- `src/gf16_mesh_2x2_top.v` — 2×2 mesh of 4 `trinity_gf16_tile` with round-robin
  NoC stub: North/South/East/West 4-bit flit + req/ack handshake; combinational
  arbitration (no DSP). Tile IDs 2'b00..2'b11 = NW/NE/SW/SE.
- `src/d2d_holo_mesh.v` — die-to-die holographic mesh.
- `src/trinity_mesh_adapter_stub.v` — adapter stub.
> This is the silicon counterpart of `trios-mesh`'s `mru_forward` SRAM
> (16 × 32 B = 512 B). Software and RTL must keep identical constants.

### `gHashTag/trinity-fpga` (Zig; HEAD 2026-06-30)
- `docs/v3-squeeze/S-18-multi-tile-noc.md` — multi-tile NoC design.
- `ttsky26c/holo/` — holographic mesh for TTSKY26c (`tt_um_qbrain_holo.v`).
- FPGA synthesis: OpenXC7 + Vivado, flash scripts; Artix-7/Kintex-7 supported.
  This is the toolchain for AX7203 (XC7A200T = Artix-7).

### `gHashTag/openFPGALoader` (C++; HEAD 2026-06-20)
Universal FPGA bitstream loader. Supports Xilinx + FT2232H cable — i.e. flashes
the AX7203 with the $25 programmer in the BOM.

## C · Specs & orchestration

### `gHashTag/trinity` (Zig)
- `specs/tri/tvc_service/tvc_mesh.tri` — Pub/Sub mesh (v1.0.0) for distributed
  index-update propagation (NodeId 32 B, signed IndexUpdate).
- `specs/cli/mesh-command-v1.tri`, `specs/cli/mesh-v3.tri` — mesh CLI specs.

### `gHashTag/trinity-node` (Rust)
DePIN daemon, pre-silicon (tape-out 2026-12-16). 4-layer model: Network/API
(JSON-RPC :9933, Bittensor BIT-0011, DePIN P2P) · Consensus (miner 12 s /
validator 30 s) · Attestation (2-of-3 multi-sig) · Chip HAL (PUF, Lucas POST,
anchor 0x47C0). Triad roles: **Phi = compute, Euler = Routing/control (on-chip
mesh NoC), Gamma = storage/proof.**

### `gHashTag/t27` (Zig; HEAD 2026-06-29)
SSOT toolchain `.t27 → Verilog → Tiny Tapeout`. Numeric format registry
(GoldenFloat GF16 default, GF4–GF32). Catalog = 83 formats live.

### `gHashTag/trinity-contracts` (Solidity)
On-chain mining: ERC-20 TRI (3^27 supply), MiningPool 7-check claim,
ChipRegistry PUF, JobProver Groth16 BN254. Base L2. Mining requires physical
TT SKY26b Trinity chip (Phi+Euler+Gamma 2-of-3 attestation). → billing layer
for a future remote-internet service.

## D · TRI-NET chip line (silicon)
| Chip | Repo | Role | Status |
|------|------|------|--------|
| Phi | tt-trinity-phi | φ-anchor, node id/trust, Lucas POST φ²+φ⁻²=3, seed 0x47C0 | TTSKY26b, silicon Dec 2026 |
| Euler | tt-trinity-euler | e-engine, packet signature/ZK, **routing/control** | TTSKY26b, silicon Dec 2026 |
| Gamma | tt-trinity-gamma | γ-surface 8×4 / 32-PE mesh, compute | TTSKY26b, silicon Dec 2026 |
| Corona | tt-trinity-corona | format-conformance oracle (read-only ROM) | TTGF26a, silicon Oct–Nov 2026 |
| **Radio** | **(new) tri-net-radio** | **SDR↔FPGA PHY + mesh transport + video** | **TODO — this MVP** |

## E · What is genuinely MISSING (the MVP work)
1. **Radio PHY**: receive IQ samples from AntSDR E200 over Gigabit Ethernet into
   AX7203, demodulate (BPSK/QPSK → OFDM later), frame sync, CRC, hand clean
   bytes up. Nothing in any repo does this yet.
2. **Radio `Transport` impl** for `trios-mesh` (so existing routing rides the radio).
3. **Video transport**: FPGA H.264/MJPEG encode → packetize → AntSDR TX; PTT mode.
4. **AES-256 in FPGA** for the radio link (crypto exists in software/X25519; the
   in-fabric AES line item is roadmap Q4 2026).
5. New repo `tri-net-radio` to host rtl/ fpga/ firmware/ docs/.
