# P201Mini / P203Mini — Datasheet Facts [CITED]

> v2.3 (2026-07-01): частично на железе — M1 crypto-smoke + AD9361 loopback + M3 mesh 11→13 прогнаны на P201Mini; полный PHY/TDMA/полёты по-прежнему только в симуляции.

Источник: P201Mini_P203Mini User Manual.pdf (V1.0, 2023.05.25), PuZhi Tech / PZSDR (aithtech.com),
Google Drive folder ID `1mKWlSyf95ehVl2OCfvKzC0WvL2Q04cEy`. Прочитан полностью (14 стр.) через gws.

## Что это
All-in-one интегрированные платы **SDR + FPGA** на одном PCB. Одна плата = полный узел TRI-NET
(радио + ПЛИС + GbE + GPS/PPS-синхронизация). Заменяют связку «отдельный AntSDR E200 + AX7203»
для MVP. Программно совместимы между собой — drop-in замена.

## Главный контроллер (общий для обеих плат)
- SoC: **XILINX XC7Z020-2CLG400I** (Zynq-7020)
- CPU: Dual ARM Cortex-A9 @ **766 MHz**
- Logic cells: **85K** [VERIFIED — Zynq-7020 = 85K LC, 220 DSP, 4.9 Mb BRAM]
- DDR3: **1 GB** (2× MT41K256M16TW, DDR3L)
- QSPI Flash: 256 Mb (32 MB); E2PROM: 256 Kb

## Различие плат
| | RF-чип | Частоты | Полоса сигнала |
|---|---|---|---|
| **P201Mini** | **AD9361** | **70 MHz – 6 GHz** | **200 KHz – 56 MHz** |
| **P203Mini** | **AD9363** | **325 MHz – 3.8 GHz** | **200 KHz – 20 MHz** |

## Радио-тракт
- Усилитель мощности (PA): **10–15 dBm** (≈10–32 мВт) — низкий, для дальности нужен внешний PA
- TX1 / RX1: разъёмы SMA
- Balun: 10 MHz – 6 GHz; усилитель: 50 MHz – 6 GHz; RF switch SPDT: 9 KHz – 8 GHz

## Синхронизация (критично для TDMA / Remote-ID / mesh)
- Опорный генератор: 40 MHz VCTCXO, **0.1 ppm**
- ADF4002BRUZ зарезервирован (PLL)
- **PPS + 10 MHz clock input (mmcx)** — встроенный вход внешней синхронизации.
  Это снимает главную проблему mesh: общий временной слот для TDMA без отдельного GPSDO.

## Интерфейсы
- **1× Gigabit Ethernet** (RTL8211 PHY, RGMII со стороны PL) — backhaul/линк узла
- 1× USB OTG; 1× UART; 1× JTAG; 1× SD card
- Расширение: 8× 3.3V IO + 2× 1.8V IO (12P 2.54mm header)

## Форм-фактор и питание (ключ к полётопригодности)
- Плата: **85 × 50 × 2.2 mm**
- В корпусе: **95 × 55 × 23 mm** (корпус = радиатор)
- Питание: **TypeC (5V USB)** или XH2.54 (5V / 1A)
- Темп. диапазон: индустриальный **−40 … +85 °C**
- Загрузка: JTAG / QSPI / SD

## Контент Drive-папки (датащиты подтверждают on-board компоненты)
01.Datasheet: AD9361, FPGA, DDR3, **GPS**, RTL8211 (GbE PHY).
Также: 02.Software Tools and Drivers, 03.Boot Test, 04.Hardware, 05.Course_Demos,
Function Block Diagram.pdf.

## Контакты вендора
sales@aithtech.com, support@aithtech.com, WhatsApp +86 15026866269.

## Вывод для архитектуры TRI-NET
- **P201/P203 Mini = основной MVP-узел.** Компактны (85×50 мм, ~5V/1A), индустриальный temp,
  встроенный GPS/PPS+10M синхро, GbE — пригодны к полёту (в отличие от AX7203 >1 кг, нелётный).
- P201Mini предпочтителен (70M–6G, BW 56M) — покрывает 5.8 GHz ISM (≤100 мВт лучший
  регуляторный путь TH NBTC / SG IMDA). P203Mini (325M–3.8G) — для нижних диапазонов.
- Слабое место: PA 10–15 dBm → для дальности нужен внешний PA + LNA.
- 3× AX7203 (в наличии) → наземная разработка / фиксированные приподнятые узлы / тяжёлые вычисления.
- AntSDR E200 → опциональная альтернатива.
- φ² + φ⁻² = 3 → треугольник из 3 узлов P201Mini = первая самовосстанавливающаяся сеть.
